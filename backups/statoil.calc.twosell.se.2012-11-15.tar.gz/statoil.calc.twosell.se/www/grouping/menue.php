<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<a href="index.php"> Lista grupper </a> | <a href="edit.php">Skapa ny grupp</a>  | 
<a href="recalculate_all.php" target="_blank" title="<?php echo utf8_encode('Varning, g�rs normalt automatiskt nattetid (det syns p� datum n�r gruppen r�knades om senast), kan ta upp till flera timmar, f�r ej startas om ber�kning redan p�g�r. Ska endast startas av TWOSELL-offline ansvarig.st�ng inte logg-f�nstret tills ber�kningen �r klar');?>">
    <?php echo utf8_encode('R&auml;kna om grupper');?></a>  |  <a href="list_all_products.php?&month=15"> Alla produkter ej medlem i n&aring;gon grupp</a> | <a href="listexcel.php"> Skapa excel lista av "Alla produkter ej medlem i n&aring;gon grupp"</a> | <a href="list_of_stores.php">List of Store</a> | <a href="http://admin.twosell.se/">TWOSELL-länkar</a>
    <br> <a href="list_variation.php"> Lista variation </a> | <a href="edit_variation.php">Skapa ny variation</a>  | <a href="http://admin.twosell.se/variation/" target="_blank"> Link for predefined variation</a>


<?php 
//|  <a href="list_members_in_group.php?meta_group_id=">Lista alla artiklar</a>  
//|  <a href="list_members_in_group.php?meta_group_id=0">Lista artiklar utan grupp</a>

?>
<br><br>
