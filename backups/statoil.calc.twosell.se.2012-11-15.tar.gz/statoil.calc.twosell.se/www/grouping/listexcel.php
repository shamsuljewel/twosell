<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>
       TWOSELL skapa excell
</title>
</head>
<body>

<?php include("menue.php"); ?>

<h1>Funkar inte just nu </h1>


OK, lite knölig version men det går att göra en excel<br>
av alla produkter som inte ingår i en grupp. <br><br>

Lite knöligt men går på några minuter när man vet hur man gör,
i framtiden kan vi automatisera det mer...
<br>
<br>

1. klicka på länken nedan.<br>
 En sida öppnas (kryptisk text)<br>
2. Ställ in fonten så att åäö ser normala ut (UTF-8)<br>
3. högerklicka på texten och välj "Visa källkod"<br>
Ett fönster öppnad med text, ser lite snyggare ut än nyss<br>
4. Välja "Arkiv spara sida" eller något liknande för att spara filen på skrivbordet.<br>
ändelsen på filen sätts till .txt   (skriv det i slutet på det föreslagna filnamnet)<br>

<br>
5. Öppna Excel<br>
6. välj importera textfil (under Data-fliken)<br>
7. välj ; som avskiljar<br>
8. välj att inte ha " som textavskiljare (då blir det pannkaka av allt).<br>
9. välj slutför<br>
10. Därefter är hela excellfilne inläst<br>
<br>
<br>
<a href="http://debug.calc.twosell.se:8080/php/ramin2/list_all_products_txt.php" target="_blank">Klicka här för att börja (öppnas i nytt fönster)</a>

</body>